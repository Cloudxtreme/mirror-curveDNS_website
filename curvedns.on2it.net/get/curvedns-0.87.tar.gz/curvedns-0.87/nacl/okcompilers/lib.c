int not3(int n)
{
  return n != 3;
}

int bytes(int n)
{
  return (n + 7) / 8;
}

long long shr32(long long n)
{
  return n >> 32;
}

double double5(void)
{
  return 5.0;
}

int intbytes(void)
{
  return sizeof(int);
}

int longbytes(void)
{
  return sizeof(long);
}
