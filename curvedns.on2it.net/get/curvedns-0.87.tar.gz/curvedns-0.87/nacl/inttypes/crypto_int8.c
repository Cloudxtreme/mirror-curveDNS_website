#include "crypto_int8.h"
#include "signed.h"
DOIT(8,crypto_int8)
