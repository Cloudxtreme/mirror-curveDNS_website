#include "crypto_uint32.h"
#include "unsigned.h"
DOIT(32,crypto_uint32)
